public class NotInTeamException extends Exception {
  public NotInTeamException() {}
  public NotInTeamException(String msg) {
    super(msg);
  }
}