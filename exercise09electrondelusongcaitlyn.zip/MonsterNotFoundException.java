public class MonsterNotFoundException extends Exception{
  public MonsterNotFoundException() {}
  public MonsterNotFoundException(String msg) {
    super(msg);
  }
}