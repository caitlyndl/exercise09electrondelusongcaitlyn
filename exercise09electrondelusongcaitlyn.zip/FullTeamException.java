public class FullTeamException extends Exception {
  public FullTeamException() {}
  public FullTeamException(String msg) {
    super(msg);
  }
}